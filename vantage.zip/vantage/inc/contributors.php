<?php
return json_decode( '{
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1766,
		"score": 73.99511855489993,
		"percent": 50.87619330669286
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 2364,
		"score": 37.02182163733898,
		"percent": 25.454778517446346
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 641,
		"score": 32.58965201812874,
		"percent": 22.407389409640675
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 26,
		"score": 1.1271779541543332,
		"percent": 0.7750041436051051
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 4,
		"score": 0.4550165597287811,
		"percent": 0.31285185972548013
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 23,
		"score": 0.2527523249487679,
		"percent": 0.17378276288953987
	}
}', true );