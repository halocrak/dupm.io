<?php

return array (
	'ABeeZee' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Abel' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Abhaya Libre' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
		'subsets' => 
		array (
			0 => 'sinhala',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Abril Fatface' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Aclonica' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Acme' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Actor' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Adamina' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Advent Pro' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Aguafina Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Akronim' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Aladin' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Aldrich' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Alef' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
		),
	),
	'Alegreya' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '900',
			5 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Alegreya SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '900',
			5 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Alegreya Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Alegreya Sans SC' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Alex Brush' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Alfa Slab One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Alice' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Alike' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Alike Angular' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Allan' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Allerta' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Allerta Stencil' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Allura' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Almendra' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Almendra Display' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Almendra SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Amarante' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Amaranth' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Amatic SC' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Amatica SC' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Amethysta' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Amiko' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '600',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Amiri' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'arabic',
		),
	),
	'Amita' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Anaheim' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Andada' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Andika' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'cyrillic-ext',
			2 => 'latin',
			3 => 'latin-ext',
			4 => 'cyrillic',
		),
	),
	'Angkor' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Annie Use Your Telescope' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Anonymous Pro' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Antic' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Antic Didone' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Antic Slab' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Anton' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Arapey' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Arbutus' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Arbutus Slab' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Architects Daughter' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Archivo Black' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Archivo Narrow' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Aref Ruqaa' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'arabic',
		),
	),
	'Arima Madurai' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '700',
			6 => '800',
			7 => '900',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'tamil',
		),
	),
	'Arimo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'hebrew',
			3 => 'cyrillic-ext',
			4 => 'greek-ext',
			5 => 'latin',
			6 => 'latin-ext',
			7 => 'cyrillic',
		),
	),
	'Arizonia' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Armata' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Artifika' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Arvo' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Arya' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Asap' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '700',
			5 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Asar' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Asset' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Assistant' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '800',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
		),
	),
	'Astloch' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Asul' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Athiti' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Atma' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'bengali',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Atomic Age' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Aubrey' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Audiowide' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Autour One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Average' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Average Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Averia Gruesa Libre' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Averia Libre' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Averia Sans Libre' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Averia Serif Libre' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bad Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'cyrillic',
		),
	),
	'Baloo' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'devanagari',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Baloo Bhai' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'vietnamese',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Baloo Bhaina' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'oriya',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Baloo Chettan' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'malayalam',
		),
	),
	'Baloo Da' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'bengali',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Baloo Paaji' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'gurmukhi',
		),
	),
	'Baloo Tamma' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'kannada',
		),
	),
	'Baloo Thambi' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'tamil',
		),
	),
	'Balthazar' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bangers' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Basic' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Battambang' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Baumans' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bayon' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Belgrano' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Belleza' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'BenchNine' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bentham' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Berkshire Swash' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bevan' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bigelow Rules' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bigshot One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bilbo' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bilbo Swash Caps' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'BioRhyme' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'BioRhyme Expanded' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Biryani' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Bitter' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Black Ops One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bokor' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Bonbon' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Boogaloo' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bowlby One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bowlby One SC' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Brawler' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Bree Serif' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bubblegum Sans' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bubbler One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Buda' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Buenard' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Bungee' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Bungee Hairline' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Bungee Inline' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Bungee Outline' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Bungee Shade' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Butcherman' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Butterfly Kids' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Cabin' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '600',
			5 => '600italic',
			6 => '700',
			7 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Cabin Condensed' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Cabin Sketch' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Caesar Dressing' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cagliostro' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cairo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'arabic',
		),
	),
	'Calligraffitti' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cambay' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Cambo' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Candal' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cantarell' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cantata One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Cantora One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Capriola' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Cardo' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'greek-ext',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Carme' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Carrois Gothic' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Carrois Gothic SC' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Carter One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Catamaran' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'tamil',
		),
	),
	'Caudex' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'greek-ext',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Caveat' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Caveat Brush' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Cedarville Cursive' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Ceviche One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Changa' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'arabic',
		),
	),
	'Changa One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Chango' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Chathura' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
			4 => '800',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Chau Philomene One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Chela One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Chelsea Market' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Chenla' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Cherry Cream Soda' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cherry Swash' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Chewy' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Chicle' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Chivo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '900',
			3 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Chonburi' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Cinzel' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cinzel Decorative' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Clicker Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Coda' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Coda Caption' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Codystar' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Coiny' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'tamil',
		),
	),
	'Combo' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Comfortaa' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'latin',
			3 => 'latin-ext',
			4 => 'cyrillic',
		),
	),
	'Coming Soon' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Concert One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Condiment' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Content' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Contrail One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Convergence' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cookie' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Copse' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Corben' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Cormorant' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Cormorant Garamond' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Cormorant Infant' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Cormorant SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Cormorant Unicase' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Cormorant Upright' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Courgette' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Cousine' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'hebrew',
			3 => 'cyrillic-ext',
			4 => 'greek-ext',
			5 => 'latin',
			6 => 'latin-ext',
			7 => 'cyrillic',
		),
	),
	'Coustard' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Covered By Your Grace' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Crafty Girls' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Creepster' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Crete Round' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Crimson Text' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '600',
			3 => '600italic',
			4 => '700',
			5 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Croissant One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Crushed' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Cuprum' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Cutive' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Cutive Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Damion' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Dancing Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Dangrek' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'David Libre' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'hebrew',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Dawning of a New Day' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Days One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Dekko' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Delius' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Delius Swash Caps' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Delius Unicase' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Della Respira' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Denk One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Devonshire' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Dhurjati' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Didact Gothic' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'greek-ext',
			3 => 'latin',
			4 => 'latin-ext',
			5 => 'cyrillic',
		),
	),
	'Diplomata' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Diplomata SC' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Domine' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Donegal One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Doppio One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Dorsa' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Dosis' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Dr Sugiyama' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Droid Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Droid Sans Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Droid Serif' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Duru Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Dynalight' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'EB Garamond' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'cyrillic-ext',
			2 => 'latin',
			3 => 'latin-ext',
			4 => 'cyrillic',
		),
	),
	'Eagle Lake' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Eater' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Economica' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Eczar' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Ek Mukta' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'El Messiri' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'cyrillic',
			2 => 'arabic',
		),
	),
	'Electrolize' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Elsie' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Elsie Swash Caps' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Emblema One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Emilys Candy' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Engagement' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Englebert' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Enriqueta' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Erica One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Esteban' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Euphoria Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ewert' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Exo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Exo 2' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Expletus Sans' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '600',
			5 => '600italic',
			6 => '700',
			7 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Fanwood Text' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Farsan' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'vietnamese',
			2 => 'latin',
			3 => 'latin-ext',
		),
	),
	'Fascinate' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Fascinate Inline' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Faster One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Fasthand' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Fauna One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Federant' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Federo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Felipa' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Fenix' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Finger Paint' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Fira Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'latin',
			3 => 'latin-ext',
			4 => 'cyrillic',
		),
	),
	'Fira Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '700',
			7 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'latin',
			3 => 'latin-ext',
			4 => 'cyrillic',
		),
	),
	'Fjalla One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Fjord One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Flamenco' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Flavors' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Fondamento' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Fontdiner Swanky' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Forum' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Francois One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Frank Ruhl Libre' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
			4 => '900',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Freckle Face' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Fredericka the Great' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Fredoka One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Freehand' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Fresca' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Frijole' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Fruktur' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Fugaz One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'GFS Didot' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'greek',
		),
	),
	'GFS Neohellenic' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'greek',
		),
	),
	'Gabriela' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Gafata' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Galada' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'bengali',
			1 => 'latin',
		),
	),
	'Galdeano' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Galindo' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Gentium Basic' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Gentium Book Basic' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Geo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Geostar' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Geostar Fill' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Germania One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Gidugu' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Gilda Display' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Give You Glory' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Glass Antiqua' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Glegoo' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Gloria Hallelujah' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Goblin One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Gochi Hand' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Gorditas' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Goudy Bookletter 1911' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Graduate' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Grand Hotel' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Gravitas One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Great Vibes' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Griffy' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Gruppo' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Gudea' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Gurajada' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Habibi' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Halant' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Hammersmith One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Hanalei' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Hanalei Fill' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Handlee' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Hanuman' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Happy Monkey' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Harmattan' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'arabic',
		),
	),
	'Headland One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Heebo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '800',
			6 => '900',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
		),
	),
	'Henny Penny' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Herr Von Muellerhoff' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Hind' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Hind Guntur' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Hind Madurai' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'tamil',
		),
	),
	'Hind Siliguri' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'bengali',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Hind Vadodara' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Holtwood One SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Homemade Apple' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Homenaje' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell DW Pica' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell DW Pica SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell Double Pica' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell Double Pica SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell English' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell English SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell French Canon' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell French Canon SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell Great Primer' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'IM Fell Great Primer SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Iceberg' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Iceland' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Imprima' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Inconsolata' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Inder' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Indie Flower' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Inika' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Inknut Antiqua' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Irish Grover' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Istok Web' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Italiana' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Italianno' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Itim' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Jacques Francois' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Jacques Francois Shadow' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Jaldi' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Jim Nightshade' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Jockey One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Jolly Lodger' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Jomhuria' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'arabic',
		),
	),
	'Josefin Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Josefin Slab' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Joti One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Judson' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Julee' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Julius Sans One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Junge' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Jura' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'latin',
			3 => 'latin-ext',
			4 => 'cyrillic',
		),
	),
	'Just Another Hand' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Just Me Again Down Here' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Kadwa' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
		),
	),
	'Kalam' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Kameron' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Kanit' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Kantumruy' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Karla' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Karma' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Katibeh' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'arabic',
		),
	),
	'Kaushan Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Kavivanar' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'tamil',
		),
	),
	'Kavoon' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Kdam Thmor' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Keania One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Kelly Slab' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Kenia' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Khand' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Khmer' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Khula' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
			4 => '800',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Kite One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Knewave' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Kotta One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Koulen' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Kranky' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Kreon' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Kristi' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Krona One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Kumar One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Kumar One Outline' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Kurale' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'La Belle Aurore' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Laila' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Lakki Reddy' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Lalezar' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'arabic',
		),
	),
	'Lancelot' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Lateef' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'arabic',
		),
	),
	'Lato' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '700',
			7 => '700italic',
			8 => '900',
			9 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'League Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Leckerli One' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Ledger' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Lekton' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Lemon' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Lemonada' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'arabic',
		),
	),
	'Libre Baskerville' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Libre Franklin' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Life Savers' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Lilita One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Lily Script One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Limelight' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Linden Hill' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Lobster' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Lobster Two' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Londrina Outline' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Londrina Shadow' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Londrina Sketch' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Londrina Solid' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Lora' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Love Ya Like A Sister' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Loved by the King' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Lovers Quarrel' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Luckiest Guy' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Lusitana' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Lustria' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Macondo' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Macondo Swash Caps' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Mada' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'arabic',
		),
	),
	'Magra' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Maiden Orange' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Maitree' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Mako' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Mallanna' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Mandali' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Marcellus' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Marcellus SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Marck Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Margarine' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Marko One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Marmelad' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Martel' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Martel Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '600',
			4 => '700',
			5 => '800',
			6 => '900',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Marvel' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Mate' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Mate SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Maven Pro' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '700',
			3 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'McLaren' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Meddon' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'MedievalSharp' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Medula One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Meera Inimai' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'tamil',
		),
	),
	'Megrim' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Meie Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Merienda' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Merienda One' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Merriweather' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
			6 => '900',
			7 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Merriweather Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
			6 => '800',
			7 => '800italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Metal' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Metal Mania' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Metamorphous' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Metrophobic' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Michroma' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Milonga' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Miltonian' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Miltonian Tattoo' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Miniver' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Miriam Libre' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Mirza' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'arabic',
		),
	),
	'Miss Fajardose' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mitr' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Modak' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Modern Antiqua' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mogra' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Molengo' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Molle' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Monda' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Monofett' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Monoton' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Monsieur La Doulaise' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Montaga' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Montez' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Montserrat' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Montserrat Alternates' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Montserrat Subrayada' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Moul' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Moulpali' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Mountains of Christmas' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Mouse Memoirs' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mr Bedfort' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mr Dafoe' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mr De Haviland' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mrs Saint Delafield' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mrs Sheppards' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Mukta Vaani' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '800',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Muli' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Mystery Quest' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'NTR' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Neucha' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'cyrillic',
		),
	),
	'Neuton' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'New Rocker' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'News Cycle' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Niconne' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Nixie One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nobile' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nokora' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Norican' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Nosifer' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Nothing You Could Do' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Noticia Text' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Noto Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'devanagari',
			4 => 'greek-ext',
			5 => 'latin',
			6 => 'latin-ext',
			7 => 'cyrillic',
		),
	),
	'Noto Serif' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'greek-ext',
			4 => 'latin',
			5 => 'latin-ext',
			6 => 'cyrillic',
		),
	),
	'Nova Cut' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nova Flat' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nova Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'latin',
		),
	),
	'Nova Oval' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nova Round' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nova Script' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nova Slim' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nova Square' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Numans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Nunito' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Nunito Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '800',
			11 => '800italic',
			12 => '900',
			13 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Odor Mean Chey' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Offside' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Old Standard TT' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Oldenburg' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Oleo Script' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Oleo Script Swash Caps' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Open Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '600',
			5 => '600italic',
			6 => '700',
			7 => '700italic',
			8 => '800',
			9 => '800italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'greek-ext',
			4 => 'latin',
			5 => 'latin-ext',
			6 => 'cyrillic',
		),
	),
	'Open Sans Condensed' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'greek-ext',
			4 => 'latin',
			5 => 'latin-ext',
			6 => 'cyrillic',
		),
	),
	'Oranienbaum' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Orbitron' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '700',
			3 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Oregano' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Orienta' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Original Surfer' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Oswald' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Over the Rainbow' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Overlock' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '900',
			5 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Overlock SC' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ovo' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Oxygen' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Oxygen Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'PT Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'PT Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'PT Sans Caption' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'PT Sans Narrow' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'PT Serif' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'PT Serif Caption' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'cyrillic-ext',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Pacifico' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Palanquin' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Palanquin Dark' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Paprika' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Parisienne' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Passero One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Passion One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Pathway Gothic One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Patrick Hand' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Patrick Hand SC' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Pattaya' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
			4 => 'thai',
		),
	),
	'Patua One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Pavanam' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'tamil',
		),
	),
	'Paytone One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Peddana' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Peralta' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Permanent Marker' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Petit Formal Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Petrona' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Philosopher' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'cyrillic',
		),
	),
	'Piedra' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Pinyon Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Pirata One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Plaster' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Play' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'latin',
			3 => 'latin-ext',
			4 => 'cyrillic',
		),
	),
	'Playball' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Playfair Display' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '900',
			5 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Playfair Display SC' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
			4 => '900',
			5 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Podkova' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Poiret One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Poller One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Poly' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Pompiere' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Pontano Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Poppins' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Port Lligat Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Port Lligat Slab' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Pragati Narrow' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Prata' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Preahvihear' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Press Start 2P' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Pridi' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Princess Sofia' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Prociono' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Prompt' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Prosto One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Proza Libre' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '500',
			3 => '500italic',
			4 => '600',
			5 => '600italic',
			6 => '700',
			7 => '700italic',
			8 => '800',
			9 => '800italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Puritan' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Purple Purse' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Quando' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Quantico' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Quattrocento' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Quattrocento Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Questrial' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Quicksand' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Quintessential' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Qwigley' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Racing Sans One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Radley' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rajdhani' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Rakkas' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'arabic',
		),
	),
	'Raleway' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Raleway Dots' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ramabhadra' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Ramaraja' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Rambla' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rammetto One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ranchers' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rancho' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Ranga' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Rasa' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Rationale' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Ravi Prakash' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Redressed' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Reem Kufi' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'arabic',
		),
	),
	'Reenie Beanie' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Revalia' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rhodium Libre' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Ribeye' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ribeye Marrow' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Righteous' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Risque' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Roboto' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '700',
			9 => '700italic',
			10 => '900',
			11 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'greek-ext',
			4 => 'latin',
			5 => 'latin-ext',
			6 => 'cyrillic',
		),
	),
	'Roboto Condensed' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '700',
			5 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'greek-ext',
			4 => 'latin',
			5 => 'latin-ext',
			6 => 'cyrillic',
		),
	),
	'Roboto Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '500',
			7 => '500italic',
			8 => '700',
			9 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'greek-ext',
			4 => 'latin',
			5 => 'latin-ext',
			6 => 'cyrillic',
		),
	),
	'Roboto Slab' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'cyrillic-ext',
			3 => 'greek-ext',
			4 => 'latin',
			5 => 'latin-ext',
			6 => 'cyrillic',
		),
	),
	'Rochester' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Rock Salt' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Rokkitt' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Romanesco' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ropa Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rosario' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Rosarivo' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rouge Script' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Rozha One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Rubik' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '700',
			7 => '700italic',
			8 => '900',
			9 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'cyrillic',
		),
	),
	'Rubik Mono One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Rubik One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Ruda' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rufina' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ruge Boogie' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ruluko' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rum Raisin' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Ruslan Display' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Russo One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Ruthie' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Rye' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sacramento' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sahitya' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
		),
	),
	'Sail' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Salsa' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sanchez' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sancreek' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sansita One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sarala' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Sarina' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sarpanch' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
			5 => '900',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Satisfy' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Scada' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Scheherazade' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'arabic',
		),
	),
	'Schoolbell' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Scope One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Seaweed Script' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Secular One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Sevillana' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Seymour One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Shadows Into Light' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Shadows Into Light Two' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Shanti' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Share' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Share Tech' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Share Tech Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Shojumaru' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Short Stack' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Shrikhand' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'gujarati',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Siemreap' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Sigmar One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Signika' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Signika Negative' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '600',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Simonetta' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '900',
			3 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sintony' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sirin Stencil' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Six Caps' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Skranji' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Slabo 13px' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Slabo 27px' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Slackey' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Smokum' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Smythe' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sniglet' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '800',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Snippet' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Snowburst One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sofadi One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sofia' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sonsie One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Sorts Mill Goudy' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Source Code Pro' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '600',
			5 => '700',
			6 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Source Sans Pro' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '900',
			11 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Source Serif Pro' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '600',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Space Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Special Elite' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Spicy Rice' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Spinnaker' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Spirax' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Squada One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sree Krushnadevaraya' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Sriracha' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Stalemate' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Stalinist One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Stardos Stencil' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Stint Ultra Condensed' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Stint Ultra Expanded' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Stoke' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Strait' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sue Ellen Francisco' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Suez One' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Sumana' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Sunshiney' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Supermercado One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Sura' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Suranna' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Suravaram' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Suwannaphum' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Swanky and Moo Moo' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Syncopate' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Tangerine' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Taprom' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'khmer',
		),
	),
	'Tauri' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Taviraj' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Teko' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Telex' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Tenali Ramakrishna' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Tenor Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Text Me One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'The Girl Next Door' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Tienne' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
			2 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Tillana' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '600',
			3 => '700',
			4 => '800',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Timmana' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'telugu',
			1 => 'latin',
		),
	),
	'Tinos' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'greek',
			2 => 'hebrew',
			3 => 'cyrillic-ext',
			4 => 'greek-ext',
			5 => 'latin',
			6 => 'latin-ext',
			7 => 'cyrillic',
		),
	),
	'Titan One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Titillium Web' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '200italic',
			2 => '300',
			3 => '300italic',
			4 => 'regular',
			5 => 'italic',
			6 => '600',
			7 => '600italic',
			8 => '700',
			9 => '700italic',
			10 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Trade Winds' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Trirong' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '100',
			1 => '100italic',
			2 => '200',
			3 => '200italic',
			4 => '300',
			5 => '300italic',
			6 => 'regular',
			7 => 'italic',
			8 => '500',
			9 => '500italic',
			10 => '600',
			11 => '600italic',
			12 => '700',
			13 => '700italic',
			14 => '800',
			15 => '800italic',
			16 => '900',
			17 => '900italic',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
			3 => 'thai',
		),
	),
	'Trocchi' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Trochut' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Trykker' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Tulpen One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Ubuntu' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '300',
			1 => '300italic',
			2 => 'regular',
			3 => 'italic',
			4 => '500',
			5 => '500italic',
			6 => '700',
			7 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'greek-ext',
			3 => 'latin',
			4 => 'latin-ext',
			5 => 'cyrillic',
		),
	),
	'Ubuntu Condensed' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'greek-ext',
			3 => 'latin',
			4 => 'latin-ext',
			5 => 'cyrillic',
		),
	),
	'Ubuntu Mono' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'greek',
			1 => 'cyrillic-ext',
			2 => 'greek-ext',
			3 => 'latin',
			4 => 'latin-ext',
			5 => 'cyrillic',
		),
	),
	'Ultra' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Uncial Antiqua' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Underdog' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Unica One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'UnifrakturCook' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'UnifrakturMaguntia' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Unkempt' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
			1 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Unlock' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Unna' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'VT323' => 
	array (
		'category' => 'monospace',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'vietnamese',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Vampiro One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Varela' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Varela Round' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'hebrew',
			1 => 'latin',
		),
	),
	'Vast Shadow' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Vesper Libre' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => '500',
			2 => '700',
			3 => '900',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Vibur' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Vidaloka' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Viga' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Voces' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Volkhov' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Vollkorn' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => 'regular',
			1 => 'italic',
			2 => '700',
			3 => '700italic',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Voltaire' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Waiting for the Sunrise' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Wallpoet' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Walter Turncoat' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Warnes' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Wellfleet' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Wendy One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Wire One' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Work Sans' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '200',
			2 => '300',
			3 => 'regular',
			4 => '500',
			5 => '600',
			6 => '700',
			7 => '800',
			8 => '900',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Yanone Kaffeesatz' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '200',
			1 => '300',
			2 => 'regular',
			3 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Yantramanav' => 
	array (
		'category' => 'sans-serif',
		'variants' => 
		array (
			0 => '100',
			1 => '300',
			2 => 'regular',
			3 => '500',
			4 => '700',
			5 => '900',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Yatra One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'devanagari',
			1 => 'latin',
			2 => 'latin-ext',
		),
	),
	'Yellowtail' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Yeseva One' => 
	array (
		'category' => 'display',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
			2 => 'cyrillic',
		),
	),
	'Yesteryear' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
	'Yrsa' => 
	array (
		'category' => 'serif',
		'variants' => 
		array (
			0 => '300',
			1 => 'regular',
			2 => '500',
			3 => '600',
			4 => '700',
		),
		'subsets' => 
		array (
			0 => 'latin',
			1 => 'latin-ext',
		),
	),
	'Zeyada' => 
	array (
		'category' => 'handwriting',
		'variants' => 
		array (
			0 => 'regular',
		),
		'subsets' => 
		array (
			0 => 'latin',
		),
	),
);