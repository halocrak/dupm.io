<?php

return array(
	'web_application_icons' => __( 'Web Application Icons', 'vantage' ),
	'accessibility_icons' => __( 'Accessibility Icons', 'vantage' ),
	'hand_icons' => __( 'Hand Icons', 'vantage' ),
	'transportation_icons' => __( 'Transportation Icons', 'vantage' ),
	'gender_icons' => __( 'Gender Icons', 'vantage' ),
	'file_type_icons' => __( 'File Type Icons', 'vantage' ),
	'spinner_icons' => __( 'Spinner Icons', 'vantage' ),
	'form_control_icons' => __( 'Form Control Icons', 'vantage' ),
	'payment_icons' => __( 'Payment Icons', 'vantage' ),
	'chart_icons' => __( 'Chart Icons', 'vantage' ),
	'currency_icons' => __( 'Currency Icons', 'vantage' ),
	'text_editor_icons' => __( 'Text Editor Icons', 'vantage' ),
	'directional_icons' => __( 'Directional Icons', 'vantage' ),
	'video_player_icons' => __( 'Video Player Icons', 'vantage' ),
	'brand_icons' => __( 'Brand Icons', 'vantage' ),
	'medical_icons' => __( 'Medical Icons', 'vantage' ),
);